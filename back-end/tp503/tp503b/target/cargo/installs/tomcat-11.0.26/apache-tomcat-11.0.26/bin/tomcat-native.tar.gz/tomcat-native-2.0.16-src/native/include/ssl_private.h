/* Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef SSL_PRIVATE_H
#define SSL_PRIVATE_H

/* Exclude unused OpenSSL features
 * even if the OpenSSL supports them
 */
#ifndef OPENSSL_NO_IDEA
#define OPENSSL_NO_IDEA
#endif
#ifndef OPENSSL_NO_KRB5
#define OPENSSL_NO_KRB5
#endif
#ifndef OPENSSL_NO_MDC2
#define OPENSSL_NO_MDC2
#endif
#ifndef OPENSSL_NO_RC5
#define OPENSSL_NO_RC5
#endif

/* OpenSSL headers */
#include <openssl/opensslv.h>
#include <openssl/ssl.h>
#include <openssl/err.h>
#include <openssl/x509.h>
#include <openssl/pem.h>
#include <openssl/pkcs12.h>
#include <openssl/crypto.h>
#include <openssl/evp.h>
#include <openssl/rand.h>
#include <openssl/x509v3.h>
#include <openssl/dh.h>
#include <openssl/bn.h>
#ifndef LIBRESSL_VERSION_NUMBER
#include <openssl/provider.h>
#endif
#include <openssl/core_names.h>

#ifndef RAND_MAX
#include <limits.h>
#define RAND_MAX INT_MAX
#endif

#define SSL_AIDX_RSA     (0)
#define SSL_AIDX_DSA     (1)
#define SSL_AIDX_ECC     (3)
#define SSL_AIDX_MAX     (4)

/*
 * The length of error message strings. MUST BE AT LEAST 256.
 */
#define TCN_OPENSSL_ERROR_STRING_LENGTH 256

/*
 * Define the SSL Protocol options
 */
#define SSL_PROTOCOL_NONE       (0)
#define SSL_PROTOCOL_SSLV2      (1<<0)
#define SSL_PROTOCOL_SSLV3      (1<<1)
#define SSL_PROTOCOL_TLSV1      (1<<2)
#define SSL_PROTOCOL_TLSV1_1    (1<<3)
#define SSL_PROTOCOL_TLSV1_2    (1<<4)
#define SSL_PROTOCOL_TLSV1_3    (1<<5)

#define SSL_MODE_CLIENT         (0)
#define SSL_MODE_SERVER         (1)
#define SSL_MODE_COMBINED       (2)

#define SSL_DEFAULT_CACHE_SIZE  (256)
#define SSL_MAX_PASSWORD_LEN    (256)

#define SSL_CVERIFY_UNSET           (-1)
#define SSL_CVERIFY_NONE            (0)
#define SSL_CVERIFY_OPTIONAL        (1)
#define SSL_CVERIFY_REQUIRE         (2)
#define SSL_CVERIFY_OPTIONAL_NO_CA  (3)
#define SSL_VERIFY_PEER_STRICT      (SSL_VERIFY_PEER|SSL_VERIFY_FAIL_IF_NO_PEER_CERT)

#define SSL_VERIFY_ERROR_IS_OPTIONAL(errnum) \
   ((errnum == X509_V_ERR_DEPTH_ZERO_SELF_SIGNED_CERT) \
    || (errnum == X509_V_ERR_SELF_SIGNED_CERT_IN_CHAIN) \
    || (errnum == X509_V_ERR_UNABLE_TO_GET_ISSUER_CERT_LOCALLY) \
    || (errnum == X509_V_ERR_CERT_UNTRUSTED) \
    || (errnum == X509_V_ERR_UNABLE_TO_VERIFY_LEAF_SIGNATURE))

#define SSL_DEFAULT_PASS_PROMPT "Some of your private key files are encrypted for security reasons.\n" \
                                "In order to read them you have to provide the pass phrases.\n"        \
                                "Enter pass phrase:"

#define SSL_CIPHERS_ALWAYS_DISABLED         ("!aNULL:!eNULL:!EXP:")

#if defined(SSL_OP_NO_TLSv1_3)
#define HAVE_TLSV1_3
#endif

/* Check for SSL_CONF support */
#if defined(SSL_CONF_FLAG_FILE)
#define HAVE_SSL_CONF_CMD
#endif

/**
 * The following features all depend on TLS extension support.
 * Within this block, check again for features (not version numbers).
 */
#if !defined(OPENSSL_NO_TLSEXT) && defined(SSL_set_tlsext_host_name)

/* ECC */
#if !defined(OPENSSL_NO_EC) && defined(TLSEXT_ECPOINTFORMAT_uncompressed)
#define HAVE_ECC
#endif

/* OCSP */
#if !defined(OPENSSL_NO_OCSP) && defined(SSL_CTX_set_tlsext_status_cb)
#define HAVE_OCSP
#define OCSP_STATUS_OK              0
#define OCSP_STATUS_REVOKED         1
#define OCSP_STATUS_UNKNOWN         2
#define OCSP_NO_CHECK_DEFAULT       1
#define OCSP_SOFT_FAIL_DEFAULT      1
#define OCSP_VERIFY_FLAGS_DEFAULT   0
/* 15 minutes - aligns with JSSE */
#define OCSP_MAX_SKEW             900
/* 15 seconds - aligns with JSSE*/
#define OCSP_TIMEOUT_DEFAULT 15000000
/* Older versions of OpenSSL have a smaller range of OCSP error codes*/
#if !defined(X509_V_ERR_OCSP_RESP_INVALID)
#define X509_V_ERR_OCSP_RESP_INVALID      96
#endif
#if !defined(X509_V_ERR_OCSP_SIGNATURE_FAILURE)
#define X509_V_ERR_OCSP_SIGNATURE_FAILURE 97
#endif
#if !defined(X509_V_ERR_OCSP_NOT_YET_VALID)
#define X509_V_ERR_OCSP_NOT_YET_VALID     98
#endif
#if !defined(X509_V_ERR_OCSP_HAS_EXPIRED)
#define X509_V_ERR_OCSP_HAS_EXPIRED       99
#endif
#endif

#endif /* !defined(OPENSSL_NO_TLSEXT) && defined(SSL_set_tlsext_host_name) */

#define MAX_ALPN_PROTO_SIZE 255
#define SSL_SELECTOR_FAILURE_CHOOSE_MY_LAST_PROTOCOL            1

typedef struct tcn_ssl_ctxt_t tcn_ssl_ctxt_t;

typedef struct {
    char            password[SSL_MAX_PASSWORD_LEN];
    const char     *prompt;
} tcn_pass_cb_t;

extern tcn_pass_cb_t tcn_password_callback;

struct tcn_ssl_ctxt_t {
    apr_pool_t      *pool;
    SSL_CTX         *ctx;
    BIO             *bio_os;

    /* we are one or the other */
    int             mode;

    /* certificate revocation list */
    X509_STORE      *crl;

    X509            *certs[SSL_AIDX_MAX];
    EVP_PKEY        *keys[SSL_AIDX_MAX];

    /* for client or downstream server authentication */
    int             verify_depth;
    int             verify_mode;

    /* Password callback */
    tcn_pass_cb_t   *cb_data;

    /* for client: List of protocols to request via ALPN.
     * for server: List of protocols to accept via ALPN.
     */
    /* Add from netty-tcnative */
    /* certificate verifier callback */
    jobject verifier;
    jmethodID verifier_method;

    /* Holds the alpn protocols, each of them prefixed with the len of the protocol */
    unsigned char   *alpn_proto_data;
    unsigned int    alpn_proto_len;
    int             alpn_selector_failure_behavior;
    /* End add from netty-tcnative */
    int             no_ocsp_check;
    int             ocsp_soft_fail;
    int             ocsp_timeout;
    int             ocsp_verify_flags;
};

#ifdef HAVE_SSL_CONF_CMD
typedef struct tcn_ssl_conf_ctxt_t tcn_ssl_conf_ctxt_t;

struct tcn_ssl_conf_ctxt_t {
    apr_pool_t      *pool;
    SSL_CONF_CTX    *cctx;
    int             no_ocsp_check;
    int             ocsp_soft_fail;
    int             ocsp_timeout;
    int             ocsp_verify_flags;
};
#endif

typedef struct {
    apr_pool_t      *pool;
    tcn_ssl_ctxt_t  *ctx;
    /* for client or downstream server authentication */
    int             verify_depth;
    int             verify_mode;
    enum {
        PHA_NONE = 0,   /* Before PHA */
        PHA_STARTED,    /* PHA req sent to client but no response */
        PHA_COMPLETE    /* Client has returned cert */
    } pha_state;
} tcn_ssl_conn_t;


/*
 *  Additional Functions
 */
void        SSL_init_app_data_idx(void);
/* The app_data2 is used to store the tcn_ssl_ctxt_t pointer for the SSL instance. */
void       *SSL_get_app_data2(SSL *);
void        SSL_set_app_data2(SSL *, void *);
/* The app_data3 is used to store the handshakeCount pointer for the SSL instance. */
void       *SSL_get_app_data3(const SSL *);
void        SSL_set_app_data3(SSL *, void *);
/* The app_data4 is used to store the destroyCount pointer for the SSL instance. */
void       *SSL_get_app_data4(const SSL *);
void        SSL_set_app_data4(SSL *, void *);
int         SSL_password_prompt(tcn_pass_cb_t *);
int         SSL_password_callback(char *, int, int, void *);
EVP_PKEY   *SSL_dh_GetParamFromFile(const char *);
#ifdef HAVE_ECC
int         SSL_ec_GetParamFromFile(const char *);
#endif

int         SSL_CTX_use_certificate_chain(SSL_CTX *, const char *, int);
int         SSL_callback_SSL_verify(int, X509_STORE_CTX *);
int         SSL_rand_seed(const char *file);
int         SSL_callback_alpn_select_proto(SSL *, const unsigned char **, unsigned char *, const unsigned char *, unsigned int, void *);
void        SSL_callback_add_keylog(SSL_CTX *);

#define SSL_ERR_get() ERR_get_error()
#define SSL_ERR_clear() ERR_clear_error()

#endif /* SSL_PRIVATE_H */
